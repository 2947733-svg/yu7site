# yu7.site — патч с видео-интеграциями (2026-05-06)

## Что в этом патче

5 файлов с встроенными видео-инструкциями:

| Файл | Что добавлено | Видео |
|---|---|---|
| `repair.html` | Раздел «Видео-инструкции» перед «Документация по ремонту» | Карбон 1-5, перенос руля, подушка SRS, XiaoAi (SU7) — **8 видео** |
| `maintenance.html` | Раздел «Видео-инструкции: салонный фильтр» перед источниками | Фильтр YU7, фильтр SU7 — **2 видео** |
| `wheels-specs.html` | Раздел «Видео: что такое CDC» перед связанными статьями | CDC — **1 видео** |
| `keys.html` | Раздел «Видео: режим On approach» в блоке «Смартфон как ключ» | BT-ключ — **1 видео** |
| `search-index.json` | Перегенерированы text-поля для 4 обновлённых страниц | — |

**Всего добавлено: 12 встроенных видео.**

## Принципы вставки

- **Минимально-инвазивно.** Существующий контент не изменён.
- **Используются только текущие классы CSS:** `.video-embed`, `.video-embed-header`, `.video-embed-frame`, `.note-warning`, `.note-danger`, `.note-info`. **`article.css` НЕ ИЗМЕНЁН.**
- **Источники указаны** под каждым блоком со ссылкой на пост в Telegram.
- **Warning-блоки** добавлены перед опасными темами (подушка SRS, перенос руля, инструкция для SU7).
- **`loading="lazy"`** на всех iframe — для производительности.

## Применение

### Вариант A — вручную через WinSCP

1. Сделать бэкап текущих файлов на сервере.
2. Загрузить через WinSCP в `/var/www/u9408526/data/www/yu7.site/`:
   - `repair.html`
   - `maintenance.html`
   - `wheels-specs.html`
   - `keys.html`
   - `search-index.json`

### Вариант B — через Claude Code локально

```powershell
# 1. Бэкап
$ts = Get-Date -Format 'yyyy-MM-dd_HHmm'
Copy-Item -Path "C:\claude-test\yu7-digest\site_live" -Destination "C:\Claude\BackUp\site_live_before_videos_$ts" -Recurse

# 2. Распаковать ZIP в site_live (с заменой)
Expand-Archive -Path "yu7site_videos_patch.zip" -DestinationPath "C:\claude-test\yu7-digest\site_live" -Force

# 3. Локальная проверка
cd C:\claude-test\yu7-digest\site_live
npx serve .
# Открыть http://localhost:3000/repair.html
# Проверить http://localhost:3000/maintenance.html
# Проверить http://localhost:3000/wheels-specs.html
# Проверить http://localhost:3000/keys.html

# 4. Если всё ок — финальный ZIP для деплоя
Compress-Archive -Path "C:\claude-test\yu7-digest\site_live\*" -DestinationPath "C:\Claude\BackUp\site_live_$ts_DEPLOY.zip"

# 5. Загрузка через WinSCP на хостинг u9408526@31.31.196.158
```

## Проверка после деплоя

1. Открыть https://yu7.site/repair.html — прокрутить до «Видео-инструкции»
2. Открыть https://yu7.site/maintenance.html — увидеть «Видео-инструкции: салонный фильтр»
3. Открыть https://yu7.site/wheels-specs.html — увидеть видео CDC перед «Связанные статьи»
4. Открыть https://yu7.site/keys.html — найти видео в разделе «Смартфон как ключ»
5. Проверить поиск по сайту: «карбон», «фильтр», «CDC», «on approach» — должны находиться

## YouTube видео (для справки)

| ID | Тема | Просмотры на момент патча |
|---|---|---|
| `4SitJE9ubQM` | Карбон 1/5 | 3 |
| `NunAYM_-YB4` | Карбон 2/5 | 2 |
| `idLaOpEUer4` | Карбон 3/5 | 4 |
| `EHKzyaAOPSg` | Карбон 4/5 ⭐ | **14 302** |
| `mzoQOlWqgf8` | Карбон 5/5 ⭐ | **21 039** |
| `0yeyZ6LpEow` | Перенос руля YU7 ⭐ | **1 274** |
| `DzTEk-d5pqY` | Разборка подушки SRS | новое |
| `kLi85f0uNJQ` | XiaoAi (SU7) | 0 |
| `vM6gxuXoVD0` | Фильтр YU7 | 8 |
| `cICTBnI48fI` | Фильтр SU7 | 1 |
| `4e6Q7B5AWh0` | CDC | 1 |
| `hK00SD8VsTg` | BT-ключ | 1 |

## Откат

Если что-то пошло не так:
```powershell
Remove-Item -Path "C:\claude-test\yu7-digest\site_live" -Recurse -Force
Copy-Item -Path "C:\Claude\BackUp\site_live_before_videos_<timestamp>" -Destination "C:\claude-test\yu7-digest\site_live" -Recurse
```

---

**Автор патча:** Claude (через Roman / Herbert Wells)
**Дата:** 2026-05-06
